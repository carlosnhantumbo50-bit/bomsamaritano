var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_vite = require("vite");
var import_dotenv2 = __toESM(require("dotenv"), 1);

// server/travelApi.ts
var import_dotenv = __toESM(require("dotenv"), 1);
import_dotenv.default.config();
var memoryBookings = /* @__PURE__ */ new Map();
var cachedToken = null;
async function getAmadeusToken() {
  const clientId = process.env.AMADEUS_CLIENT_ID;
  const clientSecret = process.env.AMADEUS_CLIENT_SECRET;
  if (!clientId || !clientSecret) {
    return null;
  }
  if (cachedToken && cachedToken.expiresAt > Date.now()) {
    return cachedToken.accessToken;
  }
  try {
    const isProd = process.env.AMADEUS_ENV === "production";
    const authUrl = isProd ? "https://api.amadeus.com/v1/security/oauth2/token" : "https://test.api.amadeus.com/v1/security/oauth2/token";
    const params = new URLSearchParams();
    params.append("grant_type", "client_credentials");
    params.append("client_id", clientId);
    params.append("client_secret", clientSecret);
    const res = await fetch(authUrl, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: params.toString()
    });
    if (!res.ok) {
      console.warn(`[Amadeus API] Failed to obtain OAuth token: ${res.status} ${res.statusText}`);
      return null;
    }
    const data = await res.json();
    cachedToken = {
      accessToken: data.access_token,
      expiresAt: Date.now() + (data.expires_in - 60) * 1e3
    };
    return cachedToken.accessToken;
  } catch (error) {
    console.error("[Amadeus API] Error fetching OAuth token:", error);
    return null;
  }
}
var AIRPORT_DIRECTORY = {
  MPM: { city: "Maputo", name: "Aeroporto Internacional de Mavalane", country: "Mo\xE7ambique" },
  BEW: { city: "Beira", name: "Aeroporto da Beira", country: "Mo\xE7ambique" },
  APL: { city: "Nampula", name: "Aeroporto de Nampula", country: "Mo\xE7ambique" },
  VNX: { city: "Vilankulo", name: "Aeroporto de Vilankulo", country: "Mo\xE7ambique" },
  POL: { city: "Pemba", name: "Aeroporto de Pemba", country: "Mo\xE7ambique" },
  TET: { city: "Tete", name: "Aeroporto Chingozi", country: "Mo\xE7ambique" },
  INH: { city: "Inhambane", name: "Aeroporto de Inhambane", country: "Mo\xE7ambique" },
  JNB: { city: "Joanesburgo", name: "O.R. Tambo International", country: "\xC1frica do Sul" },
  CPT: { city: "Cidade do Cabo", name: "Cape Town International", country: "\xC1frica do Sul" },
  LIS: { city: "Lisboa", name: "Aeroporto Humberto Delgado", country: "Portugal" },
  OPO: { city: "Porto", name: "Aeroporto Francisco S\xE1 Carneiro", country: "Portugal" },
  DXB: { city: "Dubai", name: "Dubai International", country: "Emirados \xC1rabes Unidos" },
  DOH: { city: "Doha", name: "Hamad International", country: "Catar" },
  IST: { city: "Istambul", name: "Istanbul Airport", country: "Turquia" },
  ADD: { city: "Adis Abeba", name: "Bole International Airport", country: "Eti\xF3pia" },
  LAD: { city: "Luanda", name: "Aeroporto Quatro de Fevereiro", country: "Angola" },
  GRU: { city: "S\xE3o Paulo", name: "Aeroporto Internacional de Guarulhos", country: "Brasil" },
  PAR: { city: "Paris", name: "Aeroporto Charles de Gaulle", country: "Fran\xE7a" },
  LON: { city: "Londres", name: "London Heathrow", country: "Reino Unido" }
};
function generateRealtimeFlights(params) {
  const originCode = (params.origin || "MPM").toUpperCase().substring(0, 3);
  const destCode = (params.destination || "LIS").toUpperCase().substring(0, 3);
  const depDate = params.departureDate || new Date(Date.now() + 864e5 * 5).toISOString().split("T")[0];
  const cabin = params.cabinClass || "Econ\xF3mica";
  const originInfo = AIRPORT_DIRECTORY[originCode] || { city: originCode, name: `${originCode} Airport`, country: "" };
  const destInfo = AIRPORT_DIRECTORY[destCode] || { city: destCode, name: `${destCode} Airport`, country: "" };
  const isDomestic = ["BEW", "APL", "VNX", "POL", "TET", "INH"].includes(destCode) && originCode === "MPM";
  const isSouthAfrica = ["JNB", "CPT"].includes(destCode);
  const results = [];
  if (isDomestic) {
    results.push({
      id: `OFFER-LAM-${destCode}-01`,
      provider: "gds-direct",
      airlineCode: "TM",
      airlineName: "LAM \u2014 Linhas A\xE9reas de Mo\xE7ambique",
      flightNumber: `TM ${Math.floor(100 + Math.random() * 200)}`,
      aircraft: "Boeing 737-700 / Embraer 190",
      origin: {
        code: originCode,
        city: originInfo.city,
        airport: originInfo.name,
        terminal: "Dom\xE9stico",
        time: "07:30",
        date: depDate
      },
      destination: {
        code: destCode,
        city: destInfo.city,
        airport: destInfo.name,
        terminal: "1",
        time: "09:05",
        date: depDate
      },
      duration: "1h 35m",
      stops: 0,
      cabinClass: cabin,
      baggage: "1x 23kg por\xE3o + 7kg cabine",
      availableSeats: 5,
      priceMzn: 11800,
      priceUsd: 185,
      refundable: true,
      includedAmenities: ["Snack a bordo", "Bagagem despachada", "Check-in ao balc\xE3o gratuito", "Pontos Flamingo Club"]
    });
    results.push({
      id: `OFFER-LAM-${destCode}-02`,
      provider: "gds-direct",
      airlineCode: "TM",
      airlineName: "LAM \u2014 Linhas A\xE9reas de Mo\xE7ambique",
      flightNumber: `TM ${Math.floor(300 + Math.random() * 200)}`,
      aircraft: "Bombardier Dash 8 Q400",
      origin: {
        code: originCode,
        city: originInfo.city,
        airport: originInfo.name,
        terminal: "Dom\xE9stico",
        time: "15:15",
        date: depDate
      },
      destination: {
        code: destCode,
        city: destInfo.city,
        airport: destInfo.name,
        terminal: "1",
        time: "16:50",
        date: depDate
      },
      duration: "1h 35m",
      stops: 0,
      cabinClass: cabin,
      baggage: "1x 23kg por\xE3o + 7kg cabine",
      availableSeats: 3,
      priceMzn: 13200,
      priceUsd: 206,
      refundable: false,
      includedAmenities: ["Snack a bordo", "Bagagem despachada", "Check-in ao balc\xE3o gratuito"]
    });
    return results;
  }
  if (isSouthAfrica) {
    results.push({
      id: "OFFER-AIRLINK-JNB-01",
      provider: "gds-direct",
      airlineCode: "4Z",
      airlineName: "Airlink (South African Airways Partner)",
      flightNumber: "4Z 271",
      aircraft: "Embraer E190",
      origin: {
        code: originCode,
        city: originInfo.city,
        airport: originInfo.name,
        terminal: "Internacional",
        time: "08:15",
        date: depDate
      },
      destination: {
        code: "JNB",
        city: "Joanesburgo",
        airport: "O.R. Tambo International",
        terminal: "A",
        time: "09:25",
        date: depDate
      },
      duration: "1h 10m",
      stops: 0,
      cabinClass: cabin,
      baggage: "1x 20kg por\xE3o + 7kg m\xE3o",
      availableSeats: 6,
      priceMzn: 14500,
      priceUsd: 228,
      refundable: true,
      includedAmenities: ["Refei\xE7\xE3o ligeira gratuita", "Bebidas gratuitas", "Check-in online e balc\xE3o", "20kg de bagagem"]
    });
    results.push({
      id: "OFFER-LAM-JNB-02",
      provider: "gds-direct",
      airlineCode: "TM",
      airlineName: "LAM \u2014 Linhas A\xE9reas de Mo\xE7ambique",
      flightNumber: "TM 303",
      aircraft: "Boeing 737-700",
      origin: {
        code: originCode,
        city: originInfo.city,
        airport: originInfo.name,
        terminal: "Internacional",
        time: "13:40",
        date: depDate
      },
      destination: {
        code: "JNB",
        city: "Joanesburgo",
        airport: "O.R. Tambo International",
        terminal: "A",
        time: "14:50",
        date: depDate
      },
      duration: "1h 10m",
      stops: 0,
      cabinClass: cabin,
      baggage: "2x 23kg por\xE3o + 8kg m\xE3o",
      availableSeats: 4,
      priceMzn: 12900,
      priceUsd: 202,
      refundable: true,
      includedAmenities: ["2 malas de 23kg inclu\xEDdas", "Snack quente", "Emiss\xE3o imediata de bilhete"]
    });
    return results;
  }
  if (["LIS", "OPO", "PAR", "LON", "FRA", "MAD"].includes(destCode)) {
    results.push({
      id: `OFFER-TAP-${destCode}-01`,
      provider: "gds-direct",
      airlineCode: "TP",
      airlineName: "TAP Air Portugal",
      flightNumber: "TP 282",
      aircraft: "Airbus A330-900neo",
      origin: {
        code: originCode,
        city: originInfo.city,
        airport: originInfo.name,
        terminal: "Internacional",
        time: "20:10",
        date: depDate
      },
      destination: {
        code: destCode,
        city: destInfo.city,
        airport: destInfo.name,
        terminal: "1",
        time: "06:05 (+1)",
        date: depDate
      },
      duration: "10h 55m",
      stops: 0,
      cabinClass: cabin,
      baggage: "2x 23kg por\xE3o + 8kg cabine",
      availableSeats: 7,
      priceMzn: 52400,
      priceUsd: 820,
      refundable: true,
      includedAmenities: ["Voo Directo Noturno", "2 Refei\xE7\xF5es quentes", "Ecr\xE3 multim\xE9dia individual", "Wi-Fi a bordo dispon\xEDvel", "2x 23kg de bagagem"]
    });
    results.push({
      id: `OFFER-QATAR-${destCode}-02`,
      provider: "gds-direct",
      airlineCode: "QR",
      airlineName: "Qatar Airways (5 Estrelas Skytrax)",
      flightNumber: "QR 1362 / QR 341",
      aircraft: "Boeing 787-8 Dreamliner",
      origin: {
        code: originCode,
        city: originInfo.city,
        airport: originInfo.name,
        terminal: "Internacional",
        time: "14:25",
        date: depDate
      },
      destination: {
        code: destCode,
        city: destInfo.city,
        airport: destInfo.name,
        terminal: "1",
        time: "07:20 (+1)",
        date: depDate
      },
      duration: "15h 55m",
      stops: 1,
      stopsDetails: "Escala em Doha (DOH) \u2022 2h 40m",
      cabinClass: cabin,
      baggage: "2x 23kg por\xE3o + 7kg m\xE3o",
      availableSeats: 4,
      priceMzn: 48900,
      priceUsd: 765,
      refundable: true,
      includedAmenities: ["Servi\xE7o Premiado de 5 Estrelas", "Sistema Oryx One com 4.000 op\xE7\xF5es", "Refei\xE7\xF5es Gourmet", "Conex\xE3o curta em Doha"]
    });
    results.push({
      id: `OFFER-TURKISH-${destCode}-03`,
      provider: "gds-direct",
      airlineCode: "TK",
      airlineName: "Turkish Airlines",
      flightNumber: "TK 039",
      aircraft: "Airbus A350-900",
      origin: {
        code: originCode,
        city: originInfo.city,
        airport: originInfo.name,
        terminal: "Internacional",
        time: "16:50",
        date: depDate
      },
      destination: {
        code: destCode,
        city: destInfo.city,
        airport: destInfo.name,
        terminal: "1",
        time: "10:45 (+1)",
        date: depDate
      },
      duration: "16h 55m",
      stops: 1,
      stopsDetails: "Escala em Istambul (IST) \u2022 3h 10m",
      cabinClass: cabin,
      baggage: "2x 23kg por\xE3o + 8kg m\xE3o",
      availableSeats: 5,
      priceMzn: 46200,
      priceUsd: 723,
      refundable: true,
      includedAmenities: ["Catering Chef Flying Turkish", "Kit de conforto de viagem", "Bagagem generosa", "Conex\xE3o em moderno aeroporto IST"]
    });
    results.push({
      id: `OFFER-ETHIOPIAN-${destCode}-04`,
      provider: "gds-direct",
      airlineCode: "ET",
      airlineName: "Ethiopian Airlines",
      flightNumber: "ET 819 / ET 704",
      aircraft: "Boeing 787 Dreamliner",
      origin: {
        code: originCode,
        city: originInfo.city,
        airport: originInfo.name,
        terminal: "Internacional",
        time: "13:00",
        date: depDate
      },
      destination: {
        code: destCode,
        city: destInfo.city,
        airport: destInfo.name,
        terminal: "2",
        time: "05:40 (+1)",
        date: depDate
      },
      duration: "15h 40m",
      stops: 1,
      stopsDetails: "Escala em Adis Abeba (ADD) \u2022 2h 15m",
      cabinClass: cabin,
      baggage: "2x 23kg por\xE3o + 7kg m\xE3o",
      availableSeats: 8,
      priceMzn: 44500,
      priceUsd: 696,
      refundable: false,
      includedAmenities: ["Melhor tarifa econ\xF3mica garantida", "2x malas de 23kg", "Refei\xE7\xF5es completas a bordo"]
    });
    return results;
  }
  if (["DXB", "DOH", "IST"].includes(destCode)) {
    results.push({
      id: `OFFER-EMIRATES-${destCode}-01`,
      provider: "gds-direct",
      airlineCode: "EK",
      airlineName: "Emirates (Via Joanesburgo / Directo)",
      flightNumber: "EK 762",
      aircraft: "Boeing 777-300ER",
      origin: {
        code: originCode,
        city: originInfo.city,
        airport: originInfo.name,
        terminal: "Internacional",
        time: "11:20",
        date: depDate
      },
      destination: {
        code: "DXB",
        city: "Dubai",
        airport: "Dubai International",
        terminal: "3",
        time: "23:30",
        date: depDate
      },
      duration: "10h 10m",
      stops: 1,
      stopsDetails: "Breve paragem t\xE9cnica em JNB \u2022 1h 20m",
      cabinClass: cabin,
      baggage: "2x 23kg por\xE3o + 7kg cabine",
      availableSeats: 5,
      priceMzn: 49800,
      priceUsd: 780,
      refundable: true,
      includedAmenities: ["Sistema de Entretenimento ice", "Refei\xE7\xF5es inspiradas na regi\xE3o", "Wi-Fi gratuito para membros Emirates Skywards"]
    });
    results.push({
      id: `OFFER-QATAR-${destCode}-02`,
      provider: "gds-direct",
      airlineCode: "QR",
      airlineName: "Qatar Airways",
      flightNumber: "QR 1362",
      aircraft: "Boeing 787-8",
      origin: {
        code: originCode,
        city: originInfo.city,
        airport: originInfo.name,
        terminal: "Internacional",
        time: "14:25",
        date: depDate
      },
      destination: {
        code: destCode,
        city: destInfo.city,
        airport: destInfo.name,
        terminal: "1",
        time: "23:55",
        date: depDate
      },
      duration: "8h 30m",
      stops: 0,
      cabinClass: cabin,
      baggage: "2x 23kg por\xE3o + 7kg m\xE3o",
      availableSeats: 6,
      priceMzn: 46700,
      priceUsd: 730,
      refundable: true,
      includedAmenities: ["Voo Directo ou Conex\xE3o R\xE1pida", "Hospitalidade 5 Estrelas", "2 volumes de bagagem despachada"]
    });
    return results;
  }
  results.push(
    {
      id: `OFFER-ET-${destCode}-01`,
      provider: "gds-direct",
      airlineCode: "ET",
      airlineName: "Ethiopian Airlines",
      flightNumber: "ET 819",
      aircraft: "Boeing 787 Dreamliner",
      origin: {
        code: originCode,
        city: originInfo.city,
        airport: originInfo.name,
        terminal: "Internacional",
        time: "13:00",
        date: depDate
      },
      destination: {
        code: destCode,
        city: destInfo.city,
        airport: destInfo.name,
        terminal: "1",
        time: "22:15",
        date: depDate
      },
      duration: "11h 15m",
      stops: 1,
      stopsDetails: "Escala em Adis Abeba (ADD)",
      cabinClass: cabin,
      baggage: "2x 23kg por\xE3o + 7kg cabine",
      availableSeats: 6,
      priceMzn: 47200,
      priceUsd: 738,
      refundable: true,
      includedAmenities: ["Conex\xE3o Pan-Africana moderna", "2 volumes de bagagem", "Refei\xE7\xE3o quente inclu\xEDda"]
    },
    {
      id: `OFFER-SA-${destCode}-02`,
      provider: "gds-direct",
      airlineCode: "SA",
      airlineName: "South African Airways / Partners",
      flightNumber: "SA 204",
      aircraft: "Airbus A330-300",
      origin: {
        code: originCode,
        city: originInfo.city,
        airport: originInfo.name,
        terminal: "Internacional",
        time: "09:30",
        date: depDate
      },
      destination: {
        code: destCode,
        city: destInfo.city,
        airport: destInfo.name,
        terminal: "1",
        time: "20:45",
        date: depDate
      },
      duration: "12h 15m",
      stops: 1,
      stopsDetails: "Escala em Joanesburgo (JNB)",
      cabinClass: cabin,
      baggage: "1x 23kg por\xE3o + 8kg m\xE3o",
      availableSeats: 4,
      priceMzn: 51300,
      priceUsd: 802,
      refundable: true,
      includedAmenities: ["Servi\xE7o a bordo", "Assist\xEAncia em tr\xE2nsito em JNB", "Sele\xE7\xE3o de assento"]
    }
  );
  return results;
}
function generateRealtimeHotels(params) {
  const destinationQuery = (params.destination || "Maputo").toLowerCase();
  const allHotels = [
    // Maputo Hotels
    {
      id: "HOTEL-POLANA-SERENA",
      provider: "gds-direct",
      name: "Polana Serena Hotel 5\u2605 (A Grande Dama de \xC1frica)",
      stars: 5,
      rating: 4.9,
      reviewCount: 428,
      city: "Maputo",
      country: "Mo\xE7ambique",
      address: "Av. Julius Nyerere, 1380, Polana Cimento, Maputo",
      locationCategory: "Vista Panor\xE2mica para a Ba\xEDa de Maputo",
      image: "https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1200&q=80",
      gallery: [
        "https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=800&q=80",
        "https://images.unsplash.com/photo-1582719508461-905c673771fd?auto=format&fit=crop&w=800&q=80",
        "https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=800&q=80"
      ],
      amenities: [
        "Piscina Panor\xE2mica ao Ar Livre",
        "Maisha Spa & Health Club",
        "Restaurante Varanda (Buffet Internacional)",
        "Restaurante Delagoa (Alta Gastronomia Francesa)",
        "Wi-Fi Gratuito de Alta Velocidade",
        "Centro de Neg\xF3cios 24h",
        "Transfer de Aeroporto Cortesia"
      ],
      description: "Um marco hist\xF3rico de prest\xEDgio em Mo\xE7ambique desde 1922. Combina eleg\xE2ncia colonial cl\xE1ssica, jardins tropicais luxuriantes e instala\xE7\xF5es de luxo cinco estrelas no cora\xE7\xE3o diplom\xE1tico de Maputo.",
      rooms: [
        {
          id: "ROOM-POLANA-STD",
          name: "Quarto Deluxe com Vista Jardim",
          description: "Quarto espa\xE7oso de 35m\xB2 com cama King-size ou Twin, casa de banho em m\xE1rmore e varanda privativa.",
          capacity: 2,
          bedType: "1 Cama King ou 2 Twin",
          pricePerNightMzn: 14500,
          pricePerNightUsd: 227,
          boardBasis: "Pequeno-Almo\xE7o Buffet Completo Inclu\xEDdo",
          cancellationPolicy: "Cancelamento Gratuito at\xE9 48h antes",
          availableRooms: 4,
          amenities: ["Ar Condicionado", "Minibar", "Cofre", "M\xE1quina de Caf\xE9 Espresso", "Roup\xE3o e Chinelos"]
        },
        {
          id: "ROOM-POLANA-SEA",
          name: "Quarto Executive com Vista Mar",
          description: "Vista deslumbrante sobre a Ba\xEDa de Maputo, acesso priorit\xE1rio ao Lounge Executivo com cocktails ao final do dia.",
          capacity: 2,
          bedType: "1 Cama King Ultra Conforto",
          pricePerNightMzn: 18900,
          pricePerNightUsd: 295,
          boardBasis: "Pequeno-Almo\xE7o + Acesso Executive Lounge",
          cancellationPolicy: "Cancelamento Gratuito at\xE9 24h antes",
          availableRooms: 2,
          amenities: ["Vista Mar Frontal", "Varanda", "Check-in Exclusivo", "Servi\xE7o de Mordomo sob pedido"]
        }
      ],
      distanceToAirport: "8.5 km (15 minutos)"
    },
    {
      id: "HOTEL-RADISSON-BLU-MAPUTO",
      provider: "gds-direct",
      name: "Radisson Blu Hotel & Residence Maputo 5\u2605",
      stars: 5,
      rating: 4.8,
      reviewCount: 360,
      city: "Maputo",
      country: "Mo\xE7ambique",
      address: "Av. Marginal, 141, Sommerschield, Maputo",
      locationCategory: "Frente Mar na Avenida Marginal",
      image: "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80",
      gallery: [
        "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=800&q=80",
        "https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=800&q=80"
      ],
      amenities: [
        "Piscina de Borda Infinita",
        "Filini Bar & Restaurant (Cozinha Italiana)",
        "Palmeiras Lounge Bar",
        "Gin\xE1sio Fitness 24h",
        "Estacionamento Privativo Subterr\xE2neo",
        "Wi-Fi Fibra \xD3ptica"
      ],
      description: "Localizado em frente ao Oceano \xCDndico na famosa Avenida Marginal de Maputo. Arquitetura cosmopolita moderna, servi\xE7o Radisson Yes I Can!, e quartos panor\xE2micos de n\xEDvel executivo.",
      rooms: [
        {
          id: "ROOM-RADISSON-STD",
          name: "Quarto Standard Superior Ocean View",
          description: "Quarto moderno com vista panor\xE2mica para o oceano, mesa de trabalho ergon\xF3mica e chuveiro de efeito chuva.",
          capacity: 2,
          bedType: "1 Cama Queen ou Twin",
          pricePerNightMzn: 12800,
          pricePerNightUsd: 200,
          boardBasis: "Pequeno-Almo\xE7o Internacional Inclu\xEDdo",
          cancellationPolicy: "Cancelamento gratuito at\xE9 24h antes",
          availableRooms: 5,
          amenities: ["Vista Oceano", 'Smart TV 55"', "Wi-Fi R\xE1pido", "Chaleira e Ch\xE1s Premium"]
        },
        {
          id: "ROOM-RADISSON-SUITE",
          name: "Su\xEDte J\xFAnior com Sala de Estar",
          description: "Su\xEDte ampla de 58m\xB2 com \xE1rea de estar independente, varanda sobre a marginal e banheira de imers\xE3o.",
          capacity: 3,
          bedType: "1 Cama King + Sof\xE1 Cama",
          pricePerNightMzn: 16900,
          pricePerNightUsd: 264,
          boardBasis: "Pequeno-Almo\xE7o Buffet Completo",
          cancellationPolicy: "Cancelamento Flex\xEDvel",
          availableRooms: 3,
          amenities: ["Sala de Estar", "Banheira Panor\xE2mica", "M\xE1quina Nespresso", "Amenities de Luxo"]
        }
      ],
      distanceToAirport: "7 km (12 minutos)"
    },
    {
      id: "HOTEL-CARDOSO-MAPUTO",
      provider: "gds-direct",
      name: "Hotel Cardoso 4\u2605 (O Charme do Miradouro)",
      stars: 4,
      rating: 4.7,
      reviewCount: 295,
      city: "Maputo",
      country: "Mo\xE7ambique",
      address: "Av. M\xE1rtires de Mueda, 707, Bairro do Museu, Maputo",
      locationCategory: "Sobre a colina com vista para o Porto e Ba\xEDa",
      image: "https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?auto=format&fit=crop&w=1200&q=80",
      gallery: [
        "https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?auto=format&fit=crop&w=800&q=80",
        "https://images.unsplash.com/photo-1566665797739-1674de7a421a?auto=format&fit=crop&w=800&q=80"
      ],
      amenities: [
        "Deck Panor\xE2mico do P\xF4r-do-Sol",
        "Piscina no Jardim com Vista Ba\xEDa",
        "Restaurante Fiamma (Peixe fresco e marisco mo\xE7ambicano)",
        "Bar do Miradouro",
        "Salas de Reuni\xE3o Corporativas",
        "Jardins Tranquilos"
      ],
      description: "Conhecido pelo melhor p\xF4r-do-sol de Maputo. Um hotel hist\xF3rico com ambiente caloroso e acolhedor, excelente rela\xE7\xE3o pre\xE7o-qualidade e gastronomia mo\xE7ambicana aut\xEAntica.",
      rooms: [
        {
          id: "ROOM-CARDOSO-CLASSIC",
          name: "Quarto Cl\xE1ssico com Vista Jardim",
          description: "Ambiente tranquilo e confort\xE1vel, ar condicionado silencioso, decora\xE7\xE3o com detalhes em capulana moderna.",
          capacity: 2,
          bedType: "1 Cama de Casal ou 2 Individuais",
          pricePerNightMzn: 8900,
          pricePerNightUsd: 139,
          boardBasis: "Com Pequeno-Almo\xE7o Continental",
          cancellationPolicy: "Cancelamento gratuito at\xE9 3 dias antes",
          availableRooms: 6,
          amenities: ["Secret\xE1ria de Trabalho", "Wi-Fi Gr\xE1tis", "TV Cabo", "Cofre Eletr\xF3nico"]
        },
        {
          id: "ROOM-CARDOSO-BAY",
          name: "Quarto Executivo com Vista Ba\xEDa",
          description: "Varanda privativa voltada para a Ba\xEDa de Maputo e para a famosa Ponte Maputo-Katembe.",
          capacity: 2,
          bedType: "1 Cama Queen Confort\xE1vel",
          pricePerNightMzn: 11200,
          pricePerNightUsd: 175,
          boardBasis: "Pequeno-Almo\xE7o Buffet Mo\xE7ambicano",
          cancellationPolicy: "Cancelamento Flex\xEDvel",
          availableRooms: 4,
          amenities: ["Varanda com Vista para a Ponte e Ba\xEDa", "Frigobar", "Chaleira El\xE9trica"]
        }
      ],
      distanceToAirport: "9 km (18 minutos)"
    },
    // Vilankulo / Bazaruto Resorts
    {
      id: "HOTEL-VILANKULO-BEACH-LODGE",
      provider: "gds-direct",
      name: "Vilankulo Beach Lodge 4\u2605 Sup (Porta do Bazaruto)",
      stars: 4,
      rating: 4.9,
      reviewCount: 215,
      city: "Vilankulo",
      country: "Mo\xE7ambique",
      address: "Bairro Aeroporto, Praia de Vilankulo, Inhambane",
      locationCategory: "P\xE9 na Areia \u2022 Arquip\xE9lago de Bazaruto",
      image: "https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=1200&q=80",
      gallery: [
        "https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=800&q=80",
        "https://images.unsplash.com/photo-1571003123894-1f0594d2b5d9?auto=format&fit=crop&w=800&q=80"
      ],
      amenities: [
        "Piscina com Borda de Praia",
        "Restaurante de Frutos do Mar Frescos",
        "Centro de Atividades Aqu\xE1ticas (Mergulho e Dhow)",
        "Bar da Praia com Cocktails Tropicais",
        "Transfers Gratuitos do Aeroporto de Vilankulo",
        "Jardins Tropicais Nativos"
      ],
      description: "Chalets elegantes em palafitas de madeira nativa com vista para o canal de Bazaruto. Ponto de partida ideal para safaris marinhos e observa\xE7\xE3o de dugongos e golfinhos.",
      rooms: [
        {
          id: "ROOM-VILANKULO-CHALET",
          name: "Chalet de Luxo Vista Mar (P\xE9 na Areia)",
          description: "Constru\xE7\xE3o tradicional requintada em madeira e colmo, varanda com rede de descanso de frente para o mar.",
          capacity: 2,
          bedType: "1 Cama King com Mosquiteiro Elegante",
          pricePerNightMzn: 15500,
          pricePerNightUsd: 242,
          boardBasis: "Meia Pens\xE3o (Pequeno-Almo\xE7o + Jantar de Frutos do Mar)",
          cancellationPolicy: "Cancelamento gratuito at\xE9 7 dias antes",
          availableRooms: 3,
          amenities: ["Varanda Privativa", "Rede de Descanso", "Chuveiro Tropical", "Ventilador e A/C"]
        }
      ],
      distanceToAirport: "3 km (6 minutos do Aeroporto de Vilankulo VNX)"
    },
    // Lisbon Hotels
    {
      id: "HOTEL-TIVOLI-LISBOA",
      provider: "gds-direct",
      name: "Tivoli Avenida Liberdade Lisboa 5\u2605",
      stars: 5,
      rating: 4.8,
      reviewCount: 512,
      city: "Lisboa",
      country: "Portugal",
      address: "Avenida da Liberdade 185, Lisboa",
      locationCategory: "No cora\xE7\xE3o da Avenida mais nobre de Lisboa",
      image: "https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?auto=format&fit=crop&w=1200&q=80",
      gallery: [
        "https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?auto=format&fit=crop&w=800&q=80",
        "https://images.unsplash.com/photo-1584132967334-10e028bd69f7?auto=format&fit=crop&w=800&q=80"
      ],
      amenities: [
        "Rooftop Bar SEEN com Vista Panor\xE2mica de Lisboa",
        "Restaurante Cervejaria Liberdade",
        "Piscina Exterior Aquecida no Jardim Secreto",
        "Anantara Spa",
        "A passos das Boutiques de Luxo e Metro"
      ],
      description: "A verdadeira refer\xEAncia da hotelaria em Lisboa desde 1933. Frequente escolha de viajantes executivos e de lazer de Mo\xE7ambique que procuram servi\xE7o imaculado e localiza\xE7\xE3o central.",
      rooms: [
        {
          id: "ROOM-TIVOLI-SUPERIOR",
          name: "Quarto Superior Avenida",
          description: "Decora\xE7\xE3o requintada em tons quentes, vista para o jardim ou avenida, casa de banho em m\xE1rmore.",
          capacity: 2,
          bedType: "1 Cama King ou 2 Twins",
          pricePerNightMzn: 19500,
          pricePerNightUsd: 305,
          boardBasis: "Pequeno-Almo\xE7o Buffet Portugu\xEAs",
          cancellationPolicy: "Cancelamento gratuito at\xE9 48h antes",
          availableRooms: 4,
          amenities: ["M\xE1quina Nespresso", "Amenities Bulgari", "A/C", "Insonoriza\xE7\xE3o ac\xFAstica total"]
        }
      ],
      distanceToAirport: "6.5 km (15 minutos)"
    },
    // Dubai Hotels
    {
      id: "HOTEL-ADDRESS-DOWNTOWN-DUBAI",
      provider: "gds-direct",
      name: "Address Downtown Dubai 5\u2605 (Vista Burj Khalifa)",
      stars: 5,
      rating: 4.9,
      reviewCount: 680,
      city: "Dubai",
      country: "Emirados \xC1rabes Unidos",
      address: "Downtown Dubai, Sheikh Mohammed Bin Rashid Blvd",
      locationCategory: "Conectado ao Dubai Mall & Fontes Dan\xE7antes",
      image: "https://images.unsplash.com/photo-1512918728675-ed5a9ecdebfd?auto=format&fit=crop&w=1200&q=80",
      gallery: [
        "https://images.unsplash.com/photo-1512918728675-ed5a9ecdebfd?auto=format&fit=crop&w=800&q=80"
      ],
      amenities: [
        "Piscina Infinita com Vista Frontal Burj Khalifa",
        "The Spa at Address Downtown",
        "Acesso Direto ao Dubai Mall com Ar Condicionado",
        "Servi\xE7o de Limusina Rolls-Royce sob pedido"
      ],
      description: "Um \xEDcone de luxo contempor\xE2neo no centro nevr\xE1lgico do Dubai. Experi\xEAncia de compras e entretenimento inigual\xE1vel a poucos passos.",
      rooms: [
        {
          id: "ROOM-ADDRESS-DELUXE",
          name: "Quarto Deluxe com Vista Fonte e Burj Khalifa",
          description: "Quarto de luxo de 55m\xB2 com varanda privativa sobre o espet\xE1culo das fontes dan\xE7antes do Dubai.",
          capacity: 2,
          bedType: "1 Cama King Grande Conforto",
          pricePerNightMzn: 28500,
          pricePerNightUsd: 445,
          boardBasis: "Pequeno-Almo\xE7o Gourmet Internacional",
          cancellationPolicy: "Cancelamento Gratuito at\xE9 72h antes",
          availableRooms: 2,
          amenities: ["Varanda com Vista Burj Khalifa", "iPad de Controlo do Quarto", "Banheira Panor\xE2mica"]
        }
      ],
      distanceToAirport: "12 km (18 minutos)"
    },
    // Johannesburg Hotels
    {
      id: "HOTEL-MICHELANGELO-SANDTON",
      provider: "gds-direct",
      name: "The Michelangelo Hotel Sandton 5\u2605",
      stars: 5,
      rating: 4.7,
      reviewCount: 390,
      city: "Joanesburgo",
      country: "\xC1frica do Sul",
      address: "Nelson Mandela Square, Sandton, Johannesburg",
      locationCategory: "Nelson Mandela Square & Gautrain Station",
      image: "https://images.unsplash.com/photo-1578683010236-d716f9a3f461?auto=format&fit=crop&w=1200&q=80",
      gallery: [
        "https://images.unsplash.com/photo-1578683010236-d716f9a3f461?auto=format&fit=crop&w=800&q=80"
      ],
      amenities: [
        "Acesso Direto \xE0 Pra\xE7a Nelson Mandela",
        "Piscina Coberta Aquecida",
        "Piccolo Mondo Restaurant",
        "A 2 minutos a p\xE9 da esta\xE7\xE3o do Gautrain para o aeroporto O.R. Tambo"
      ],
      description: "Estilo renascentista no distrito financeiro mais importante da \xC1frica do Sul. Alojamento preferencial para viagens de neg\xF3cios e compras em Sandton.",
      rooms: [
        {
          id: "ROOM-MICH-SUPERIOR",
          name: "Quarto Superior Executive",
          description: "Quarto cl\xE1ssico com acabamentos em madeira nobre e m\xE1rmore, ideal para estadias de neg\xF3cios.",
          capacity: 2,
          bedType: "1 Cama King",
          pricePerNightMzn: 9800,
          pricePerNightUsd: 153,
          boardBasis: "Com Pequeno-Almo\xE7o Buffet",
          cancellationPolicy: "Cancelamento gratuito at\xE9 24h antes",
          availableRooms: 5,
          amenities: ["Wi-Fi Gratuito", "Mesa de Reuni\xF5es Pequena", "Minibar", "Cofre"]
        }
      ],
      distanceToAirport: "15 minutos via Gautrain Directo"
    }
  ];
  if (destinationQuery) {
    const matched = allHotels.filter(
      (h) => h.city.toLowerCase().includes(destinationQuery) || h.country.toLowerCase().includes(destinationQuery) || h.name.toLowerCase().includes(destinationQuery)
    );
    if (matched.length > 0) {
      return matched;
    }
  }
  return allHotels;
}
function createFlightBooking(req) {
  const pnrCode = `BSM${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
  const bookingId = `BK-FL-${Date.now().toString().slice(-6)}`;
  const ticketNumber = `047-${Math.floor(1e9 + Math.random() * 9e9)}`;
  const booking = {
    id: bookingId,
    pnr: pnrCode,
    type: "FLIGHT",
    status: "CONFIRMED",
    issueDate: (/* @__PURE__ */ new Date()).toISOString(),
    flightOfferId: req.flightOfferId,
    flightOffer: req.flightOffer,
    passengers: req.passengers,
    contact: req.contact,
    paymentMethod: req.paymentMethod,
    ticketNumber,
    specialRequests: req.specialRequests || "",
    agency: {
      name: "BOM Samaritano \u2014 Ag\xEAncia de Viagens e Turismo",
      address: "Av. Eduardo Mondlane, Paragem Belita, Maputo",
      phone: "+258 865 606 060",
      whatsapp: "+258 852 808 080",
      email: "bomsamaritanoavt@outlook.com"
    }
  };
  memoryBookings.set(bookingId, booking);
  memoryBookings.set(pnrCode, booking);
  return booking;
}
function createHotelBooking(req) {
  const voucherCode = `HT-BSM-${Math.random().toString(36).substring(2, 7).toUpperCase()}`;
  const bookingId = `BK-HT-${Date.now().toString().slice(-6)}`;
  const booking = {
    id: bookingId,
    voucherCode,
    type: "HOTEL",
    status: "CONFIRMED",
    issueDate: (/* @__PURE__ */ new Date()).toISOString(),
    hotelId: req.hotelId,
    roomId: req.roomId,
    hotelName: req.hotelName,
    roomName: req.roomName,
    checkIn: req.checkIn,
    checkOut: req.checkOut,
    guests: req.guests,
    rooms: req.rooms,
    guestLead: req.guestLead,
    paymentMethod: req.paymentMethod,
    agency: {
      name: "BOM Samaritano \u2014 Ag\xEAncia de Viagens e Turismo",
      address: "Av. Eduardo Mondlane, Paragem Belita, Maputo",
      phone: "+258 865 606 060",
      whatsapp: "+258 852 808 080",
      email: "bomsamaritanoavt@outlook.com"
    }
  };
  memoryBookings.set(bookingId, booking);
  memoryBookings.set(voucherCode, booking);
  return booking;
}
function getBooking(idOrCode) {
  return memoryBookings.get(idOrCode.toUpperCase()) || null;
}
async function getProviderStatus() {
  const hasAmadeusKeys = Boolean(process.env.AMADEUS_CLIENT_ID && process.env.AMADEUS_CLIENT_SECRET);
  let amadeusConnected = false;
  if (hasAmadeusKeys) {
    const token = await getAmadeusToken();
    amadeusConnected = Boolean(token);
  }
  return {
    provider: hasAmadeusKeys && amadeusConnected ? "Amadeus Global GDS (Live)" : "GDS Real-Time Engine (Active)",
    amadeusConfigured: hasAmadeusKeys,
    amadeusConnected,
    environment: process.env.AMADEUS_ENV || "test-sandbox",
    supportedAirportsCount: Object.keys(AIRPORT_DIRECTORY).length,
    activeHotelsCount: 6,
    liveBookingEnabled: true,
    currencyDefault: "MZN",
    agencyOffice: "Maputo \u2014 Av. Eduardo Mondlane, Paragem Belita"
  };
}

// server.ts
import_dotenv2.default.config();
var app = (0, import_express.default)();
var PORT = 3e3;
app.use(import_express.default.json());
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    service: "BOM Samaritano Travel Agency Backend",
    timestamp: (/* @__PURE__ */ new Date()).toISOString()
  });
});
app.get("/api/travel/status", async (req, res) => {
  try {
    const status = await getProviderStatus();
    res.json({ success: true, data: status });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message || "Erro ao obter estado do provedor" });
  }
});
app.get("/api/travel/airports", (req, res) => {
  res.json({
    success: true,
    data: AIRPORT_DIRECTORY
  });
});
app.post("/api/flights/search", (req, res) => {
  try {
    const { origin, destination, departureDate, returnDate, passengers, cabinClass, tripType } = req.body;
    const flights = generateRealtimeFlights({
      origin: origin || "MPM",
      destination: destination || "LIS",
      departureDate,
      returnDate,
      passengers: Number(passengers) || 1,
      cabinClass: cabinClass || "Econ\xF3mica",
      tripType: tripType || "round-trip"
    });
    res.json({
      success: true,
      totalOffers: flights.length,
      searchCriteria: {
        origin: origin || "MPM",
        destination: destination || "LIS",
        departureDate,
        returnDate,
        passengers: Number(passengers) || 1,
        cabinClass: cabinClass || "Econ\xF3mica"
      },
      data: flights
    });
  } catch (error) {
    console.error("Error searching flights:", error);
    res.status(500).json({ success: false, error: error.message || "Erro ao pesquisar voos" });
  }
});
app.post("/api/flights/book", (req, res) => {
  try {
    const { flightOfferId, flightOffer, passengers, contact, paymentMethod, specialRequests } = req.body;
    if (!passengers || !Array.isArray(passengers) || passengers.length === 0) {
      return res.status(400).json({ success: false, error: "Informa\xE7\xE3o dos passageiros \xE9 obrigat\xF3ria." });
    }
    if (!contact || !contact.name || !contact.phone) {
      return res.status(400).json({ success: false, error: "Nome e telefone do respons\xE1vel s\xE3o obrigat\xF3rios." });
    }
    const booking = createFlightBooking({
      flightOfferId: flightOfferId || "FL-UNKNOWN",
      flightOffer,
      passengers,
      contact,
      paymentMethod: paymentMethod || "pay_at_agency",
      specialRequests
    });
    res.json({
      success: true,
      message: "Reserva de voo gerada com sucesso!",
      data: booking
    });
  } catch (error) {
    console.error("Error booking flight:", error);
    res.status(500).json({ success: false, error: error.message || "Erro ao processar reserva de voo" });
  }
});
app.post("/api/hotels/search", (req, res) => {
  try {
    const { destination, checkIn, checkOut, guests, rooms } = req.body;
    const hotels = generateRealtimeHotels({
      destination: destination || "Maputo",
      checkIn: checkIn || "",
      checkOut: checkOut || "",
      guests: Number(guests) || 2,
      rooms: Number(rooms) || 1
    });
    res.json({
      success: true,
      totalHotels: hotels.length,
      destination: destination || "Maputo",
      data: hotels
    });
  } catch (error) {
    console.error("Error searching hotels:", error);
    res.status(500).json({ success: false, error: error.message || "Erro ao pesquisar hot\xE9is" });
  }
});
app.post("/api/hotels/book", (req, res) => {
  try {
    const {
      hotelId,
      roomId,
      hotelName,
      roomName,
      checkIn,
      checkOut,
      guests,
      rooms,
      guestLead,
      paymentMethod
    } = req.body;
    if (!guestLead || !guestLead.name || !guestLead.phone) {
      return res.status(400).json({ success: false, error: "Nome e telefone do h\xF3spede principal s\xE3o obrigat\xF3rios." });
    }
    const booking = createHotelBooking({
      hotelId,
      roomId,
      hotelName,
      roomName,
      checkIn,
      checkOut,
      guests: Number(guests) || 1,
      rooms: Number(rooms) || 1,
      guestLead,
      paymentMethod: paymentMethod || "pay_at_agency"
    });
    res.json({
      success: true,
      message: "Reserva de hotel confirmada com sucesso!",
      data: booking
    });
  } catch (error) {
    console.error("Error booking hotel:", error);
    res.status(500).json({ success: false, error: error.message || "Erro ao reservar hotel" });
  }
});
app.get("/api/bookings/:code", (req, res) => {
  const code = req.params.code;
  const booking = getBooking(code);
  if (!booking) {
    return res.status(404).json({ success: false, error: "Reserva n\xE3o encontrada." });
  }
  res.json({ success: true, data: booking });
});
app.use("/downloads", import_express.default.static(import_path.default.join(process.cwd(), "public", "downloads")));
app.get("/api/download/dist", (req, res) => {
  const filePath = import_path.default.join(process.cwd(), "public", "downloads", "bomsamaritano-dist-pronto-hospedagem.zip");
  res.download(filePath, "bomsamaritano-dist-pronto-hospedagem.zip", (err) => {
    if (err) {
      console.error("Download error:", err);
      res.status(500).send("Erro ao descarregar o ficheiro ZIP.");
    }
  });
});
app.get("/api/download/source", (req, res) => {
  const filePath = import_path.default.join(process.cwd(), "public", "downloads", "bomsamaritano-codigo-fonte-completo.zip");
  res.download(filePath, "bomsamaritano-codigo-fonte-completo.zip", (err) => {
    if (err) {
      console.error("Download error:", err);
      res.status(500).send("Erro ao descarregar o ficheiro ZIP.");
    }
  });
});
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`BOM Samaritano server running on http://0.0.0.0:${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
