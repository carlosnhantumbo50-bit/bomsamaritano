import React, { useState } from 'react';
import {
  Download,
  FolderArchive,
  Server,
  Globe,
  CheckCircle2,
  Copy,
  ExternalLink,
  X,
  FileCode,
  ShieldCheck,
  Sparkles,
  HelpCircle,
  Terminal,
} from 'lucide-react';

interface ExportZipModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ExportZipModal: React.FC<ExportZipModalProps> = ({ isOpen, onClose }) => {
  const [activeGuideTab, setActiveGuideTab] = useState<'cpanel' | 'vercel' | 'vps'>('cpanel');
  const [copiedText, setCopiedText] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(id);
    setTimeout(() => setCopiedText(null), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-4xl w-full shadow-2xl border border-slate-100 overflow-hidden my-8">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#11164D] to-[#1c247c] text-white p-6 sm:p-8 relative">
          <button
            onClick={onClose}
            className="absolute top-5 right-5 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
            aria-label="Fechar"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3 mb-2">
            <span className="p-2.5 rounded-2xl bg-[#F58220] text-white inline-flex">
              <FolderArchive className="w-6 h-6" />
            </span>
            <span className="text-xs font-bold tracking-widest uppercase text-orange-200 bg-white/10 px-3 py-1 rounded-full">
              Exportar para Hospedagem
            </span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-extrabold text-white mt-2">
            Descarregar Ficheiros ZIP do Projeto
          </h2>
          <p className="text-slate-300 text-sm sm:text-base mt-1 max-w-2xl">
            Escolha o pacote ideal para a sua hospedagem. Ambos os pacotes já foram gerados e estão prontos para envio ao seu servidor ou provedor de alojamento.
          </p>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-8 space-y-8 max-h-[75vh] overflow-y-auto">
          {/* Main Download Options Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Option 1: Pronto para Hospedagem (dist) */}
            <div className="relative rounded-3xl p-6 border-2 border-[#F58220] bg-orange-50/30 flex flex-col justify-between shadow-md hover:shadow-lg transition-all">
              <div className="absolute -top-3.5 right-6 bg-[#F58220] text-white text-xs font-bold px-3 py-1 rounded-full shadow-sm flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Recomendado para cPanel / Hostinger</span>
              </div>

              <div>
                <div className="w-12 h-12 rounded-2xl bg-orange-100 text-[#F58220] flex items-center justify-center mb-4">
                  <Globe className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-slate-900 mb-1">
                  ZIP Pronto para Hospedagem Web
                </h3>
                <p className="text-xs text-slate-500 font-mono mb-3">
                  bomsamaritano-dist-pronto-hospedagem.zip (~250 KB)
                </p>
                <p className="text-xs text-slate-600 mb-4 leading-relaxed">
                  Contém a aplicação já compilada e minificada (HTML, CSS, JS, Imagens, Fontes). Não requer instalação de Node.js no servidor de hospedagem.
                </p>

                <ul className="space-y-2 text-xs text-slate-700 mb-6 font-medium">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Ficheiro <code>.htaccess</code> pré-configurado (evita erros 404)</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Regra <code>_redirects</code> para Netlify / Cloudflare</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Basta extrair na pasta <code>public_html</code></span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Inclui manual em português <code>README_HOSPEDAGEM.txt</code></span>
                  </li>
                </ul>
              </div>

              <a
                href="/api/download/dist"
                download="bomsamaritano-dist-pronto-hospedagem.zip"
                className="w-full py-3.5 px-4 rounded-2xl bg-[#F58220] hover:bg-[#d96e14] text-white font-bold text-sm flex items-center justify-center gap-2 shadow-md hover:shadow-lg transition-all text-center"
              >
                <Download className="w-4 h-4" />
                <span>Baixar ZIP de Hospedagem (dist)</span>
              </a>
            </div>

            {/* Option 2: Código Fonte Completo */}
            <div className="rounded-3xl p-6 border border-slate-200 bg-white flex flex-col justify-between shadow-sm hover:shadow-md transition-all">
              <div>
                <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-[#11164D] flex items-center justify-center mb-4">
                  <FileCode className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-slate-900 mb-1">
                  ZIP do Código Fonte Completo
                </h3>
                <p className="text-xs text-slate-500 font-mono mb-3">
                  bomsamaritano-codigo-fonte-completo.zip (~150 KB)
                </p>
                <p className="text-xs text-slate-600 mb-4 leading-relaxed">
                  Contém todos os ficheiros de desenvolvimento (React 19, TypeScript, Vite, Tailwind CSS e servidor Express <code>server.ts</code>).
                </p>

                <ul className="space-y-2 text-xs text-slate-700 mb-6 font-medium">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-indigo-600 shrink-0" />
                    <span>Código fonte completo limpo (sem <code>node_modules</code>)</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-indigo-600 shrink-0" />
                    <span>Ideal para VPS Linux, Docker, Git, Render, Railway</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-indigo-600 shrink-0" />
                    <span>Servidor Node.js backend completo com APIs de viagens</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-indigo-600 shrink-0" />
                    <span>Fácil desenvolvimento com <code>npm run dev</code></span>
                  </li>
                </ul>
              </div>

              <a
                href="/api/download/source"
                download="bomsamaritano-codigo-fonte-completo.zip"
                className="w-full py-3.5 px-4 rounded-2xl bg-[#11164D] hover:bg-[#1a216e] text-white font-bold text-sm flex items-center justify-center gap-2 shadow-md hover:shadow-lg transition-all text-center"
              >
                <Download className="w-4 h-4" />
                <span>Baixar Código Fonte Completo</span>
              </a>
            </div>
          </div>

          {/* Quick Guide Step-by-Step Tabs */}
          <div className="bg-slate-50 rounded-3xl p-6 border border-slate-200">
            <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <HelpCircle className="w-5 h-5 text-[#F58220]" />
                <h4 className="font-bold text-slate-900 text-sm sm:text-base">
                  Passo a Passo Rápido para Hospedar
                </h4>
              </div>

              <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-slate-200 text-xs">
                <button
                  type="button"
                  onClick={() => setActiveGuideTab('cpanel')}
                  className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
                    activeGuideTab === 'cpanel' ? 'bg-[#11164D] text-white' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  cPanel / Hostinger
                </button>
                <button
                  type="button"
                  onClick={() => setActiveGuideTab('vercel')}
                  className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
                    activeGuideTab === 'vercel' ? 'bg-[#11164D] text-white' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Vercel / Netlify
                </button>
                <button
                  type="button"
                  onClick={() => setActiveGuideTab('vps')}
                  className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
                    activeGuideTab === 'vps' ? 'bg-[#11164D] text-white' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  VPS / Node.js
                </button>
              </div>
            </div>

            {/* Tab: cPanel */}
            {activeGuideTab === 'cpanel' && (
              <div className="space-y-3 text-xs sm:text-sm text-slate-700">
                <div className="p-3 bg-white rounded-2xl border border-slate-200 flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full bg-orange-100 text-[#F58220] font-bold flex items-center justify-center shrink-0 text-xs">
                    1
                  </span>
                  <div>
                    <p className="font-semibold text-slate-900">Baixe o ficheiro ZIP pronto para hospedagem</p>
                    <p className="text-slate-500 text-xs">Clique no botão laranja acima para descarregar o <code>bomsamaritano-dist-pronto-hospedagem.zip</code>.</p>
                  </div>
                </div>

                <div className="p-3 bg-white rounded-2xl border border-slate-200 flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full bg-orange-100 text-[#F58220] font-bold flex items-center justify-center shrink-0 text-xs">
                    2
                  </span>
                  <div>
                    <p className="font-semibold text-slate-900">Aceda ao cPanel / Gestor de Ficheiros</p>
                    <p className="text-slate-500 text-xs">Abra a pasta <strong>public_html</strong> (ou subdomínio desejado) e clique em <strong>Carregar (Upload)</strong>.</p>
                  </div>
                </div>

                <div className="p-3 bg-white rounded-2xl border border-slate-200 flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full bg-orange-100 text-[#F58220] font-bold flex items-center justify-center shrink-0 text-xs">
                    3
                  </span>
                  <div>
                    <p className="font-semibold text-slate-900">Extraia os ficheiros diretamente na raiz</p>
                    <p className="text-slate-500 text-xs">Clique com o botão direito no zip e escolha <strong>Extrair (Extract)</strong>. O <code>index.html</code> e o <code>.htaccess</code> incluído garantem funcionamento perfeito.</p>
                  </div>
                </div>
              </div>
            )}

            {/* Tab: Vercel */}
            {activeGuideTab === 'vercel' && (
              <div className="space-y-3 text-xs sm:text-sm text-slate-700">
                <div className="p-3 bg-white rounded-2xl border border-slate-200 flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full bg-indigo-100 text-[#11164D] font-bold flex items-center justify-center shrink-0 text-xs">
                    1
                  </span>
                  <div>
                    <p className="font-semibold text-slate-900">Na Vercel (vercel.com)</p>
                    <p className="text-slate-500 text-xs">Crie um novo projeto, importe o repositório ou envie a pasta descompactada. O <code>vercel.json</code> já está incluído!</p>
                  </div>
                </div>

                <div className="p-3 bg-white rounded-2xl border border-slate-200 flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full bg-indigo-100 text-[#11164D] font-bold flex items-center justify-center shrink-0 text-xs">
                    2
                  </span>
                  <div>
                    <p className="font-semibold text-slate-900">No Netlify (netlify.com)</p>
                    <p className="text-slate-500 text-xs">Arraste a pasta <code>dist</code> extraída diretamente para o <strong>Netlify Drop</strong>. O site fica no ar em 5 segundos com HTTPS gratuito.</p>
                  </div>
                </div>
              </div>
            )}

            {/* Tab: VPS */}
            {activeGuideTab === 'vps' && (
              <div className="space-y-3 text-xs text-slate-700">
                <p className="font-semibold text-slate-900">Comandos no Terminal Ubuntu / Debian com Node.js:</p>
                <div className="bg-slate-900 text-slate-100 p-3 rounded-2xl font-mono text-xs overflow-x-auto relative group">
                  <button
                    onClick={() => handleCopy(`unzip bomsamaritano-codigo-fonte-completo.zip\nnpm install\nnpm run build\nnpm start`, 'vps-cmd')}
                    className="absolute top-2 right-2 px-2.5 py-1 rounded bg-white/10 hover:bg-white/20 text-white text-[11px] flex items-center gap-1 transition-all"
                  >
                    <Copy className="w-3 h-3" />
                    <span>{copiedText === 'vps-cmd' ? 'Copiado!' : 'Copiar'}</span>
                  </button>
                  <pre className="pr-16">{`unzip bomsamaritano-codigo-fonte-completo.zip
npm install
npm run build
npm start`}</pre>
                </div>
                <p className="text-slate-500 text-xs">
                  Para manter o servidor ativo 24/7 utilize o <code>pm2 start dist/server.cjs --name bomsamaritano</code>.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 bg-slate-100 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-xs text-slate-600">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>Ficheiros testados, verificados e protegidos contra falhas de roteamento SPA.</span>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              onClick={onClose}
              className="w-full sm:w-auto px-6 py-2.5 rounded-xl border border-slate-300 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-colors"
            >
              Fechar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
